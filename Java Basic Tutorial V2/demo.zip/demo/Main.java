package demo;

/**
 *
 * @author ADMIN
 */
public class Main {

    public static void main(String[] args) {
//        Outer out = new Outer(20);
//        out.sayHello();
//        
//        Outer out2 = new Outer(200);
//        out2.sayHello();

        Outer.Inner inner = new Outer().new Inner();
        inner.showInfo();

        Calculator cal = new Calculator() {
            @Override
            public float add(float a, float b) {
                return a + b;
            }
        };
    }
}
