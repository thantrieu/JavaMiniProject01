package demo;

/**
 *
 * @author ADMIN
 */
public interface Calculator {
    float add(float a, float b);
}
