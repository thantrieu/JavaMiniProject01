/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iofile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Windows 10
 */
public class IOFile {
    public static void main(String[] args) {
        OutputStream fout = null;
        InputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(new File("C:\\Users\\Windows 10\\Documents\\Hello.mp3"));
            File f = new File("C:\\Users\\Windows 10\\Documents\\Hello2.mp3");
            f.createNewFile();
            fout = new FileOutputStream(f);
            byte[] data = new byte[1024];
            int b;
            while((b = fileInputStream.read()) != -1) {
                fout.write(data);
            }
            fout.close();
                fileInputStream.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(IOFile.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(IOFile.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            System.out.println("end game");
        }
    }
}
