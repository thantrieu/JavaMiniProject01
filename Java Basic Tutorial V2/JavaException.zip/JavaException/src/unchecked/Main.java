/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unchecked;

/**
 *
 * @author Windows 10
 */
public class Main {

    public static void main(String[] args) {
        MyMoney money = new MyMoney();
        try {
            money.debit(1000000000);
        } catch (OutOfBallanceException e) {
            System.out.println(e.getMessage());
            System.out.println(e.howToFix());
        }
    }
}
