/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unchecked;

/**
 *
 * @author Windows 10
 */
public class MyMoney {
    private long ballance = 100000000;
    private static final long MAX_DEBIT = 100000000;
    
    public void debit(long amount) {
        if(amount > MAX_DEBIT) {
            throw new OutOfBallanceException("You cannot complet this transaction");
        } else {
            ballance -= amount;
        }
    }
}
