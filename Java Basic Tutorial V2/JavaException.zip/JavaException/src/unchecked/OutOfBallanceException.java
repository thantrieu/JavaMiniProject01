/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unchecked;

/**
 *
 * @author Windows 10
 */
public class OutOfBallanceException extends RuntimeException {
    private String msg;
    
    public OutOfBallanceException(String msg) {
        super(msg);
        this.msg = msg;
    }
    
    public String howToFix() {
        return "Ensure that amount to debit is under your ballance";
    }
}
