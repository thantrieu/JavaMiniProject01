/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package custome;

/**
 *
 * @author Windows 10
 */
public class InvalidNameException extends Exception {

    private String msg;
    private String fixed;

    public InvalidNameException(String msg) {
        super(msg);
        this.msg = msg;
    }

    public InvalidNameException(String msg, Throwable err) {
        super(msg, err);
    }

    public String howToFix() {
        fixed = "Ensure all components of name are not empty";
        return this.fixed;
    }
}
