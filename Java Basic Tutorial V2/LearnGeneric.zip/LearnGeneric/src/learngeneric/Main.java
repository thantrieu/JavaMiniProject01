package learngeneric;

import java.util.ArrayList;

/**
 *
 * @author Windows 10
 */
public class Main {

    public static void main(String[] args) {
        Pair<String, String> one = new Pair<>("One", "So 1");
        Pair<String, String> cat = new Pair<>("Cat", "Con meo");
        Pair<String, String> dog = new Pair<>("Dog", "Con cho");

        Pair<String, Integer> iphone12 = new Pair<>("iPhone 12 Super Pro Max", 2000);

        Person male = new Person("Hung");
        Person female = new Person("Phuong");
        Pair<Person, Person> couple1 = new Pair<>(male, female);

        System.out.println(one.getKey() + " = " + one.getValue());
    }
}
