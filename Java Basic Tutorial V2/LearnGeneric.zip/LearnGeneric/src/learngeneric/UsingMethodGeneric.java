/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package learngeneric;

/**
 *
 * @author Windows 10
 */
public class UsingMethodGeneric {

    public static void main(String[] args) {
        Integer[] arr1 = new Integer[]{100, 20, 33, 6, 5, 4, 79, 81, 9, 6};
        Double[] arr2 = new Double[]{1.0, 2.23, 9.78, 6.3};
        String[] strings = new String[] {"One", "Two", "Three", "Five"};
        Person[] people = new Person[]{new Person("Hung"), new Person("Long")};
        // hien thi danh sach cac phan tu int:
        MethodsGeneric.sort(arr1);
        MethodsGeneric.showArray(arr1);
    }
}
