/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.List;
import javax.swing.table.AbstractTableModel;
import model.Book;

/**
 *
 * @author ADMIN
 */
public class TblModelCtr extends AbstractTableModel {

    private List<Book> books;
    private final Class[] mClasses = {Integer.class, String.class, String.class,
        String.class, Integer.class};
    private final String[] columNames
            = {"ID", "Title", "Author", "Type", "Published Year"};

    public TblModelCtr(List<Book> books) {
        this.books = books;
    }

    public void setBooks(Book book) {
        this.books.add(book);
    }
    
    @Override
    public int getRowCount() {
        return books.size();
    }

    @Override
    public int getColumnCount() {
        return columNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Book b = books.get(rowIndex);
        switch(columnIndex) {
            case 0:
                return b.getId();
            case 1:
                return b.getType();
            case 2:
                return b.getAuthor();
            case 3:
                return b.getType();
            case 4:
                return b.getpYear();
            default:
                return null;
        }
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        Book b = books.get(rowIndex);
        switch(columnIndex) {
            case 0:
                b.setId((Integer) aValue);
                break;
            case 1:
                b.setTitle((String) aValue);
                break;
            case 2:
                b.setAuthor((String) aValue);
                break;
            case 3:
                b.setType((String) aValue);
                break;
            case 4:
                b.setpYear((Integer) aValue);
        }
        System.out.println(b);
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if(columnIndex == 0) {
            return false;
        }
        return true;
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return mClasses[columnIndex];
    }

    @Override
    public String getColumnName(int column) {
        return columNames[column];
    }

}
