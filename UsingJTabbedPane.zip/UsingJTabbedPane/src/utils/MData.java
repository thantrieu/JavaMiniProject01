/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.util.ArrayList;
import java.util.List;
import model.Book;


/**
 *
 * @author ADMIN
 */
public class MData {
    private static List<String> data = new ArrayList<>();
    private static List<Book> books = new ArrayList<>();
    
    public static List<Book> getBooks() {
        Book b1 = new Book(100, "Book1", "John Nadal", "Love", 2019);
        Book b2 = new Book(101, "Book2", "John Nadal", "Love", 2018);
        Book b3 = new Book(102, "Book3", "John Nadal", "Love", 2017);
        Book b4 = new Book(103, "Book4", "John Nadal", "Love", 2016);
        Book b5 = new Book(104, "Book5", "John Nadal", "Love", 2015);
        Book b6 = new Book(105, "Book6", "John Nadal", "Love", 2014);
        
        books.add(b1);
        books.add(b2);
        books.add(b3);
        books.add(b4);
        books.add(b5);
        books.add(b6);
        
        return books;
    }
    
    public static List<String> getData() {
        data.add("Foods");
        data.add("Drinks");
        data.add("Weather");
        data.add("Love");
        data.add("Travel");
        data.add("Books");
        data.add("Music");
        data.add("Video");
        data.add("Life on Earth");
        data.add("Study");
        return data;
    }
}
