/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author ADMIN
 */
public class BangPhanCong implements Serializable {
    private LaiXe driver;
    private Tuyen tuyen;
    private int soLuot;

    public BangPhanCong() {
    }

    public BangPhanCong(LaiXe driver, Tuyen tuyen, int soLuot) {
        this.driver = driver;
        this.tuyen = tuyen;
        this.soLuot = soLuot;
    }

    public LaiXe getDriver() {
        return driver;
    }

    public void setDriver(LaiXe driver) {
        this.driver = driver;
    }

    public Tuyen getTuyen() {
        return tuyen;
    }

    public void setTuyen(Tuyen tuyen) {
        this.tuyen = tuyen;
    }

    public int getSoLuot() {
        return soLuot;
    }

    public void setSoLuot(int soLuot) {
        this.soLuot = soLuot;
    }
    
}
