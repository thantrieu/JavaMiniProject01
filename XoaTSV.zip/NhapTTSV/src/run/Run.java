package run;

import view.HomeFrm;

/**
 *
 * @author ADMIN
 */
public class Run {
    public static void main(String[] args) {
        HomeFrm homeFrm = new HomeFrm();
        homeFrm.setVisible(true);
    }
}
